import { expect, APIResponse } from "@playwright/test";
import { BaseAPI } from "../Api/BaseAPI";
export default class Assert{

    static verifyStatusCode(response:APIResponse, code:number){
        expect(response.status()).toBe(code);
    }

}
    //function can be called without help of object or instance    
    //Assert.verifyStatusCode()