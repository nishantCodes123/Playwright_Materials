import { test, expect, APIResponse } from '@playwright/test';
import { BookingAPI } from '../Api/BookingAPI';
import insert from '../TestData/insertData.json';
import update from '../TestData/updateData.json';
import Assert from '../Utils/Assert';

//test suite
test.describe('API Test Suite', ()=> {
  let bookingAPI: BookingAPI;
  let bookingId: number;
  let response: APIResponse;

  //using hooks, we are initializing TE for each test
  test.beforeEach('Create Booking API instance', async() => {
    bookingAPI = new BookingAPI();
    await bookingAPI.init();
  });

  test.afterEach('Dispose Booking API instance', async() => {
    await bookingAPI.dispose();
  });

  test('CREATE Booking', async() => {
    response = await bookingAPI.createBooking(insert);
    bookingId = await response.json().then((body) => body.bookingid);
    //above line is a lambda function, neeche waale lines do the same thing
    //which is to get the 'bookingid' from backend and store it in bookingId
    //const body = await response.json();
    //bookingId = body.bookingid;
    
    console.log(bookingId);
    Assert.verifyStatusCode(response, 200);
    
  });

  test('GET Booking', async() => {
    response = await bookingAPI.getBooking(bookingId);
    Assert.verifyStatusCode(response, 200);
  });

  test('UPDATE Booking', async() => {
    response = await bookingAPI.updateBooking(bookingId, update);
    Assert.verifyStatusCode(response, 200);
  });

  test('DELETE Booking', async() => {
    response = await bookingAPI.deleteBooking(bookingId);
    Assert.verifyStatusCode(response, 200);
  });

})