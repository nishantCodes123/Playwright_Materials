import { BaseAPI } from "./BaseAPI";
export class BookingAPI extends BaseAPI{
    async getBooking(id:number){
        return await this.RequestContext.get(`/booking/${id}`);
    }

    async createBooking(body:any){
        return await this.RequestContext.post('/booking', {
            data: body
        });
    }

    async updateBooking(id:number, body:any){
        return await this.RequestContext.put(`/booking/${id}`, {
            data: body,
            headers: {
                'Authorization': 'Basic YWRtaW46cGFzc3dvcmQxMjM=',
                'Cookie': 'token=abc123'
            }
        });
    }
    async deleteBooking(id:number){
        return await this.RequestContext.delete(`/booking/${id}`, {
            headers:{
                'Authorization': 'Basic YWRtaW46cGFzc3dvcmQxMjM=',
                'Cookie': 'token=abc123'                
            }
        })
    }
}