import { APIRequestContext,  request } from "@playwright/test";

export class BaseAPI{
    protected RequestContext!:APIRequestContext; //Definite Assignment Assertion: to avoid compile-time error, to assure that we will definitely initalize it before using

    async init() {
        this.RequestContext = await request.newContext({
            baseURL: 'https://restful-booker.herokuapp.com',
            extraHTTPHeaders:{
                'Content-Type': 'application/json'
            }
        });
    }
    async dispose(){
        await this.RequestContext.dispose();
    }
}