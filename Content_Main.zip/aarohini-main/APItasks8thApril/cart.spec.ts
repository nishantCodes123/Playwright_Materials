import { test, expect } from "@playwright/test";

test('UI + API Validation Test', async ({ page, request }) => {

  await page.goto('https://www.demoblaze.com/');
  await page.getByText('Cart').click();

  const value =  await page.getByText('Samsung galaxy s6')
  console.log(value);
    const response = await request.post('https://api.demoblaze.com/addtocart' , {
        data :{"id":"6016316c-291c-c77f-95e3-3c5ad5e53a7e","cookie":"user=114855b5-4158-dcee-0c21-98164f5661a3","prod_id":1,"flag":false}
    }
);

 const getres = await request.post('https://api.demoblaze.com/viewcart' , {
        data :{"cookie":"user=114855b5-4158-dcee-0c21-98164f5661a3","flag":false}
    }
);

console.log(getres);
console.log(response);




  const body = await getres.json();
//    console.log("API Response:", body);

   expect(response.status()).toBe(200);

   expect(body).toHaveProperty('Items');
expect(body.Items.length).toBeGreaterThan(0);
  expect(body.Items.length).toBe(1);








})