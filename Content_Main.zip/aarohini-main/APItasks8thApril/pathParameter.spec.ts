import { APIResponse, expect, test } from "@playwright/test"

test('GET API Test2', async({request}) => {
    //Path Parameter:part of URL used to identify a specific resource
    //endpoint mein khud se id nahi define karenge like below, variable mein store karke we'll pass it in endpoint
    //const response:APIResponse = await request.get('/booking/5');
    const bookingID:number = 5;
    const response:APIResponse = await request.get(`/booking/${bookingID}`); //use backticks
    const body = await response.json();
    console.log(body);
    //since values change each time, instead of matching values, we'll match the types of values
    // expect(body).toMatchObject(
    //     {
    //         firstname:"Susan",
    //         lastname:"Smith",
    //         totalprice:326,
    //         depositpaid:false,
    //     }
    // );    
    expect(body).toMatchObject(
        {
            firstname:expect.any(String),
            lastname:expect.any(String),
            totalprice:expect.any(Number),
            depositpaid:expect.any(Boolean),

            bookingdates:expect.objectContaining({
                checkout:expect.any(String)
                
            })

        }
    );
    // expect(body.bookingdates.checkin).toBe("2020-08-20");

});