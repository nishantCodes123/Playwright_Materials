import { APIResponse, expect, test } from "@playwright/test"

test('GET API Test3', async({request}) => {
 //Query Parameter used for filetering/modifying results and comes after ? in the URL 
 //and multiple query parameters are separated by &. 
 // It is used to send data to the server in key-value pairs and is commonly used for 
 // searching, filtering, sorting, and pagination in APIs.
    const response:APIResponse = await request.get('/booking',
    {
        params:{    //query parameter
    firstname:"Josh",
    lastname:"Allen"     //JSON format
    }
}
    ); 
    const body = await response.json();
    console.log(body);
    expect(response.status()).toBe(200);
});