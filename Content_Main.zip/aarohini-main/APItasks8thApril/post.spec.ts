import { APIResponse, expect, test } from "@playwright/test"

test('POST API Test', async({request}) => {

    const response:APIResponse = await request.post('/booking', { 
        data:  {   //paste this from postman body in JSON format            
                    "firstname": "Jim",
                    "lastname": "Prasad",
                    "totalprice": 67,
                    "depositpaid": true,
                    "bookingdates": {
                        "checkin": "2013-02-23",
                        "checkout": "2014-10-23"
                    },
                    "additionalneeds": "Breakfast"
                }

                /* raw format mein bhi paste kar sakte hain, but we have to convert it to JSON format using JSON.parse() 
                 
                data: JSON.parse(`{"firstname": "Jim", "lastname": "Prasad", "totalprice": 67, "depositpaid": true,"bookingdates": { "checkin": "2013-02-23","checkout": "2014-10-23"},"additionalneeds": "Breakfast"}`)

                */

    //here we have defined in header that our datatyope is JSON, so we don't need to convert or 
    // stringify the body, Playwright will automatically convert it to JSON format
    //if we hadn't, then we would have to use JSON.parse() or JSON.stringify() to convert it to JSON format
    });
    const body = await response.json();
    console.log(body);
    expect(response.status()).toBe(200);
    expect(response.ok()).toBeTruthy();
    expect(typeof body).toBe('object');
    console.log(typeof body.booking); //object
    console.log(typeof body.bookingid); //number
    console.log(typeof body); //object
    expect(body).toHaveProperty('bookingid');
    expect(typeof body.bookingid).toBe('number');
    expect(body.bookingid).toBeGreaterThan(0);
    expect(body).toHaveProperty('booking');
    expect(Array.isArray(body.booking)).toBe(false); 
    //booking is an object, not an array
});