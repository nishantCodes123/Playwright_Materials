import {test, expect, chromium, Page} from '@playwright/test';
test('UI + API TEST', async({page, request}) => {
    const browser = await chromium.launch();
    await page.goto('https://www.demoblaze.com/');

    const product = page.getByRole('link', { name: 'Samsung galaxy s6' });
    const productName = await product.textContent();
    console.log(productName);

    const response = await request.get('https://api.demoblaze.com/entries');
    const body = await response.json();

  const apiProductName = body.Items[0].title;

  console.log("UI:", productName);
  console.log("API:", apiProductName);

  expect(response.status()).toBe(200);
  expect(typeof productName).toBe("string");
  expect(typeof apiProductName).toBe("string");

  expect(productName).toBe(apiProductName);
  await browser.close();




  //also do same for POST method
  const postResponse = await request.post('https://api.demoblaze.com/entries', {
    data: {
        title: "New Product",  
        price: 100,
        description: "This is a new product",
        category: "electronics",
        image: "https://example.com/product-image.jpg"
    }
  });
    expect(postResponse.status()).toBe(200);
    
});