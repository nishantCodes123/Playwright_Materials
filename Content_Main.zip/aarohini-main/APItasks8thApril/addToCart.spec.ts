// {"id":"7cd95411-dea9-1e1b-c0b1-30f019b6da2e","cookie":"user=74c1781c-1200-645a-20f5-eb18c3cc1f3c","prod_id":2,"flag":false}

import { APIResponse, expect, test } from "@playwright/test"

test('Add to Cart API+UI Test', async({request}) => {
    //add two products to cart using post
    const response1:APIResponse = await request.post('https://www.demoblaze.com/addtocart', {
        data: {
            "id":"f90b811d-7633-74ce-57e0-ff1d76d3c1f8",
            "cookie":"QWFyb2hpbmkxNzc2MjQ1",
            "prod_id":1,
            "flag":true
        }
    })

    const response2:APIResponse = await request.post('https://www.demoblaze.com/addtocart', {
        data: {
            "id":"3e0d4883-fea2-06dd-8eda-d3fc678b26b4",
            "cookie":"QWFyb2hpbmkxNzc2MjQ1",
            "prod_id":2,
            "flag":true
        }
    })

    //get to https://demoblaze.com/cart.html and verify that both products are added to cart
    const cartResponse:APIResponse = await request.post('https://api.demoblaze.com/viewcart', {
        data: {"cookie":"QWFyb2hpbmkxNzc2MjQ1","flag":true}
    })

    console.log(cartResponse)
    const cartBody = await cartResponse.json();
    console.log(cartBody);
    expect(cartResponse.status()).toBe(200);
    expect(cartBody.Items.length).toBe(2);

});
