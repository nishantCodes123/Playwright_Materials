import { APIResponse, expect, test } from "@playwright/test"

test('DELETE API Test', async ({ request }) => {

  const response = await request.delete('/booking/41', {
    headers: {
      'Authorization': 'Basic YWRtaW46cGFzc3dvcmQxMjM=',
      'Cookie': 'token=abc123'
    }
  });

      expect(response.status()).toBe(201);

});