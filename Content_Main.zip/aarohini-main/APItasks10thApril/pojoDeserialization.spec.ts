import {test, expect} from '@playwright/test';

interface User{ //define type (pojo equivalent)

  id: number,
  userName: string,
  password: string

}

test('Deserialization', async({request}) => {
    const response = await request.get('https://fakerestapi.azurewebsites.net//api/v1/Users/1');

    //Convert JSON -> Object (Deserialization)
    const responseBody = await response.json();
    console.log("Response: ", responseBody);

    expect(response.status()).toBe(200);
    expect(responseBody.id).toBeDefined(); //checks id field: exists is not underfined or null
    expect(responseBody.userName).toBeTruthy(); //Checks name field: has value (not false, 0, empty string, null or undefined)
    
});
