import { APIResponse, expect, test } from "@playwright/test";
import Ajv from 'ajv'
import schema from '../testData/Schema.json'

test('Validate API with JSON Schema using AJV', async({request}) => {
    
    const response:APIResponse = await request.get('https://api.restful-api.dev/objects/7', {
        headers: {
            'Content-Type':'application/json'
          
        }
        });
    const body = await response.json();
    console.log("Response:", body);


    //JSON Schema Validation (external) (internal was what we did using toMatchObject function)
    const ajv = new Ajv(); //new instance of ajv
    const validate = ajv.compile(schema); //compile() converts the schema into a validation function

    const valid = validate(body); //validate() and returns true if valid else false
    console.log('Validation Result : ', valid);
    expect(valid).toBeTruthy();
    
});