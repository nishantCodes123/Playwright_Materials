import {test, expect} from '@playwright/test';

interface User{ //define type (pojo equivalent)

  id: number,
  userName: string,
  password: string

}

test('Serialization', async({request}) => {
    const usersPayload: User = { //Create object
        "id": 101,
        "userName": "Josh",
        "password": "Tring"

    };

    const response = await request.post('https://fakerestapi.azurewebsites.net//api/v1/Users',{
        data:usersPayload //Send request (Object -> JSON automatically)
    });
    const responseBody = await response.json();
    console.log("Response: ", responseBody);
    expect(response.status()).toBe(200);
    
});