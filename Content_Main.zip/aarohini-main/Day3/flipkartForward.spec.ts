import { Browser, chromium, expect, Locator, Page, test } from '@playwright/test';

test('Flipkart', async () => {
    const browser: Browser = await chromium.launch({ headless: false });
    const page: Page = await browser.newPage();

    await page.goto('https://www.flipkart.com/');
    //Check the title 
    //locate the signinbutton and click it
    //await page.waitForTimeout(2000);
    await page.locator("//span[@class='b3wTlE']").click();
    //await page.waitForTimeout(2000);
    //searching the search box and entering Mobiles
    //page.locator("//input[@style='color:#3d3d3dff']").first().click();
    // await page.waitForTimeout(2000);
    await page.locator("//input[@style='color:#3d3d3dff']").first().fill("laptop");
    //now seeing the uptionn
    await page.waitForTimeout(5000);
    const element: Locator = await page.locator("//ul[@class='VCplLH lTpUwR bRjjIF _1psv1ze5l _1psv1ze9l _1psv1ze7c _1cisqlf2']/li");
    const count: number = await element.count();
    console.log(count);

    for (let i = 0; i < count; i++) {
        let check: String | null = await element.nth(i).innerText();
        if (check?.includes("under 30000")) {
            await element.nth(i).click();
            console.log("emtrefc");
            break;
        }
    }
   // await page.waitForTimeout(3000);
})