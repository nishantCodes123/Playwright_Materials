import { test, Browser, Page, chromium, expect } from '@playwright/test';

test('OrangeHRM Login and Leave Page', async () => {

const browser: Browser = await chromium.launch({ headless:false });
const page: Page = await browser.newPage();

await page.goto("https://opensource-demo.orangehrmlive.com/");

await page.locator("//div[@class='orangehrm-login-slot']//form//input[@name='username']").fill("Admin");
await page.locator("//div[@class='orangehrm-login-slot']//form//input[@name='password']").fill("admin123");
await page.locator("//div[@class='orangehrm-login-slot']//form//button[@type='submit']").click();

await expect(page).toHaveURL(/dashboard/);

await page.locator("//span[text()='Leave']").click();

await expect(page).toHaveURL(/leave/);

});