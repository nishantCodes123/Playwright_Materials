import { test, expect, Locator } from '@playwright/test';

test('automate cross Pop-up Window and search by X-Path Backward Access selectors', async ({ page }) => {
    await page.goto('https://www.flipkart.com/');

    await page.locator("//button[text( )='Request OTP']/ancestor::div/div/span[@role='button']").click();


    const searchBox :   Locator =  page.locator("//input[@name='marketplace']/ancestor::form[contains(@class,'header-form-search')]//input[@title='Search for Products, Brands and More']");

    
    await searchBox.fill('Laptops');
    // await searchBox.fill('Mobiles');
    await page.waitForTimeout(500);

    await page.waitForSelector("//input[@name='marketplace']/ancestor::form[contains(@class,'header-form-search')]/ul/li");

    const suggestions : Locator[] = await page.locator("//input[@name='marketplace']/ancestor::form[contains(@class,'header-form-search')]/ul/li").all();

    console.log(suggestions.length);

    for (const suggestion of suggestions) {
        const text : string | null = await suggestion.textContent();
        
        if (text?.toLowerCase().includes('under 30000')) {
            console.log(`Found and clicking: ${text}`);
            await suggestion.click();
            break;
        }
    }
});