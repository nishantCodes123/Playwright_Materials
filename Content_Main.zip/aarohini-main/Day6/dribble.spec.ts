import { Browser, chromium, Locator, Page, test } from '@playwright/test';

test('Dribbble hover and print title', async () => {

    const browser: Browser = await chromium.launch({ headless: false });
    const page: Page = await browser.newPage();

    await page.goto('https://dribbble.com/tags/tooltip');
    await page.waitForTimeout(3000);


    const shot: Locator = page.locator("//a[@data-shot-thumbnail-link='24022941']").first();
    //    await page.waitForTimeout(2000);

    await shot.hover();
        await page.waitForTimeout(1000);

 const title =await shot.getByText('Dark Mode -  Chart')
   // const title = await shot.getAttribute('aria-label');
    

    console.log("Title:", title);

});