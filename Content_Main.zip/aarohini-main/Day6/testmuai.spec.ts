import {test, expect, Browser, chromium, Page, BrowserContext} from '@playwright/test';
//without any 
test('follow on twittter', async() => {
    const browser:Browser = await chromium.launch({headless:false})
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();

    await page.goto('https://www.testmuai.com/selenium-playground/window-popup-modal-demo/');


    await page.locator('//html/body/div[1]/div/section[3]/div/div/div[1]/div/div[1]/a').click();

    await page.waitForTimeout(3000);

    await expect(page).toHaveURL('https://x.com/Lambdatesting');

});