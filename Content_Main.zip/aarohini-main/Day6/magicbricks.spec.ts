import {test , expect } from '@playwright/test';

test('Magic Bricks Task Pop Up Test', async ({ page }) => {
    await page.goto("https://www.magicbricks.com/");
    await page.waitForTimeout(2000);
    await page.getByText('Login', { exact: true }).click();

    await page.waitForTimeout(2000);

    const [newwindow] = await Promise.all([
        page.waitForEvent('popup'),
        await page.locator("//div[@class='mb-login__box signup-box']/a").click()
    ]);

    await newwindow.waitForLoadState();
    console.log(await newwindow.title());
    await expect(newwindow).toHaveTitle("User Login");







});