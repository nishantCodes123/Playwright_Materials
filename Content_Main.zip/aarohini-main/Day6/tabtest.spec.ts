import {test, expect, Browser, Page, BrowserContext} from '@playwright/test';
import { chromium } from 'playwright';

test('Tab Test', async() => {
    const browser:Browser = await chromium.launch({headless:false});
    // const context:BrowserContext = await browser.newContext();
    const page:Page = await browser.newPage();
    await page.goto('https://www.testmuai.com/selenium-playground/window-popup-modal-demo/');

    await page.waitForTimeout(3000);
    console.log(await page.title());

    const [popup] = await Promise.all([
        page.waitForEvent('popup'), //waits for a new browser tab/window
        page.getByText('Follow On Twitter').click()
    ]);

    await popup.waitForLoadState(); //waits until fully loaded

    console.log(await popup.title());
    await expect(popup).toHaveTitle('Profile / X');
    await popup.getByText('Log in').click();
    await popup.close();
    await browser.close();
    
    
});