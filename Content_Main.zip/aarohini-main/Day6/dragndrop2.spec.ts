import {test, expect, Browser, chromium, Page, BrowserContext} from '@playwright/test';

test('drag n drop', async() => {
    const browser:Browser = await chromium.launch({headless:false})
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();
    await page.goto('https://demoqa.com/droppable');
    

    const source = page.locator('#draggable');
    const destination = page.locator('//html/body/div/div/div/div/div[2]/div[1]/div/div[1]/div/div[2]');

    await source.dragTo(destination);
    await page.waitForTimeout(8000);

    // await expect(destination).toHaveText('Drag Me');

    await browser.close();
});