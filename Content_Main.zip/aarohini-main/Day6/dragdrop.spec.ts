import {test, expect, Browser, chromium, Page, BrowserContext} from '@playwright/test';

test('drag n drop', async() => {
    const browser:Browser = await chromium.launch({headless:false})
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();
    await page.goto('https://the-internet.herokuapp.com/drag_and_drop');
    

    const source = page.locator('#column-a');
    const destination = page.locator('#column-b');

    await source.dragTo(destination);

    await expect(destination).toHaveText('A');

    await browser.close();
});