import {test, chromium, Browser, Page, Locator, BrowserContext} from '@playwright/test';

test('Action Test', async() => {
    const browser:Browser = await chromium.launch({headless:false})
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();

    await page.goto('https://www.keynotesupport.com/')

    const link:Locator = page.locator("a:has-text('Excel Made Easy')").first();
    await link.hover();
    await page.waitForTimeout(3000);

});