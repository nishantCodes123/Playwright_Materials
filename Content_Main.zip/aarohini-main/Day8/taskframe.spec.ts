import { test , expect, chromium , Browser, BrowserContext , Page, Locator, firefox } from "@playwright/test";

test('scroll and click', async ()=>{
    const browser :Browser = await chromium.launch({headless : false});
    const context :BrowserContext = await browser.newContext();
    const page : Page = await context.newPage();

    await page.goto('https://www.demo.guru99.com/selenium/deprecated.html');
    const frame = page.frameLocator("frame[name='packageFrame']");

    await frame.getByText('ChromeDriverService.Builder').click();
    await page.waitForTimeout(3000);
    
      const rightFrame = page.frameLocator("frame[name='classFrame']");
    await expect(rightFrame.locator('h2')).toHaveText('Class ChromeDriverService.Builder');

    await page.waitForTimeout(1000);
   const title = await page.getByTitle(/Documentation/);
       console.log(title);
   // console.log();

//     await page.reload();
//     await page.reload();
//   await page.waitForTimeout(2000);
 // await browser.close();

})