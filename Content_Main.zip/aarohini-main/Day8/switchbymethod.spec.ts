import {test, chromium, Browser, Frame, BrowserContext, Page, expect, Locator, FrameLocator} from '@playwright/test';
//switching by frameLocator Method

test('Frame test', async() => {
    const browser:Browser = await chromium.launch();
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();

    await page.goto('https://www.demo.guru99.com/selenium/deprecated.html', {timeout:60000});

    const frame :FrameLocator = page.frameLocator("frame[name='packageFrame']");

    await frame.getByText('ChromeDriverService.Builder').click();

    await page.waitForTimeout(4000);

    const rightFrame = page.frameLocator("frame[name='classFrame']");

    await expect(rightFrame.locator('h2')).toHaveText('Class ChromeDriverService.Builder');






});