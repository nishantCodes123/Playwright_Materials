import {test, chromium, Browser, Frame, BrowserContext, Page, expect, Locator} from '@playwright/test';
//switching by frame

test('Frame test', async() => {
    const browser:Browser = await chromium.launch();
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();

    await page.goto('https://www.demo.guru99.com/selenium/deprecated.html', {timeout:60000});

    //Frame By Name
    const frame:Frame | null = page.frame({name:'packageFrame'});

    if (!frame) { throw new Error('Frame not found'); }

    await frame.locator("//a[text()='ChromeDriverService.Builder']").click();
    const frame1: Frame|null = page.frame({name: 'classFrame'});

    const text = await frame1?.locator("//h2[@title='Class ChromeDriverService.Builder']").textContent();
    console.log('Text: ' + text);
    
    await expect(text).toBe('Class ChromeDriverService.Builder');
 
    await browser.close();



});
