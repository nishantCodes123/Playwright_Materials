import {test, chromium, Browser, Frame, BrowserContext, Page, expect, Locator} from '@playwright/test';
//switching by frame

test('Frame test', async() => {
    const browser:Browser = await chromium.launch();
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();

    await page.goto('https://www.demo.guru99.com/selenium/deprecated.html', {timeout:60000});

    //Frame By Name
    const frames:Frame[] = page.frames();
    for (const frame of frames) {
        if(frame.name() === 'packageFrame'){
            console.log('Found Frame: ' + frame.name());
            await frame.locator("//a[text()='ChromeDriverService.Builder']").click();
            break;            
        }
    } 
    await browser.close();
});
