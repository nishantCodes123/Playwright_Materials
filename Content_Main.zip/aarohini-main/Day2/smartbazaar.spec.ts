import { test, Browser, Page, chromium, expect } from '@playwright/test';

test('Smart Bazaar Rice Test', async () => {

const browser: Browser = await chromium.launch({ headless:false });
const page: Page = await browser.newPage();

await page.goto("https://www.smartbazaar.co.uk/");

await page.locator("//input[@type='search']").fill("rice");
await page.locator("//input[@type='search']").press("Enter");

await page.waitForSelector("//li");

const product = page.locator("//a[contains(.,'Krishna')]").first();

const card = product.locator("xpath=ancestor::li");

const src = await card.locator("img").getAttribute("src");
const price = await card.locator(".price").textContent();

console.log("Image src:", src);
console.log("Krishna Rice Price:", price);

await page.waitForTimeout(3000);

await browser.close();

});