//a test for going to rediffmail page, go to create account, 
// check if the url ends with FormName, enter full name, 
// go to check availability and get the text value and see whether the entered full name is available or not
//if yes, the test should pass, if not it should fail
import {test, Browser, BrowserContext, Page, expect} from '@playwright/test';
import {webkit, chromium, firefox} from 'playwright';

test('Rediffmail test', async() => {
    const browser:Browser = await chromium.launch({headless:false});    
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();
    await page.goto('https://www.rediff.com/');
    await page.click("//a[text()='Create Account']");
    await expect(page).toHaveURL('https://register.rediff.com/register/register.php?FormName=user_details');
    await page.locator("//html/body/div[2]/div[2]/form/div/div[2]/input").fill('Aarohini');
    await page.click("//html/body/div[2]/div[2]/form/div/div[4]/input");
    
    await page.locator('//html/body/div[2]/div[2]/form/div/div[3]/div/input').fill('Aarohini123');
    await page.click("//html/body/div[2]/div[2]/form/div/div[4]/input");

    await page.locator("//html/body/div[2]/div[2]/form/div/div[4]/input").click();
    

    const textValue = await page.locator("//html/body/div[2]/div[2]/form/div/div[5]/div/div[1]/div/span").textContent();
    // console.log(textValue);
    await expect(page.locator('//html/body/div[2]/div[2]/form/div/div[5]/div/div[1]/div/span')).toContainText("The ID you've chosen is available.");


    
    

    await page.waitForTimeout(60000);
    await browser.close();
});



























