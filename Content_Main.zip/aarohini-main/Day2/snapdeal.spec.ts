import { test, expect, Browser, BrowserContext, Page, Locator } from '@playwright/test';
import { chromium } from 'playwright';
test('open_snapdeal', async () => {

    const b: Browser = await chromium.launch({ headless: false });
    // const c:BrowserContext = await b.newContext();
    const p: Page = await b.newPage();
    await p.goto('https://www.snapdeal.com/');
    await expect(p).toHaveTitle('Shop Online for Men, Women & Kids Clothing, Shoes, Home Decor Items');

    // await p.locator("//div[@id='tab-category-0']").waitFor({state:'visible'}); //-549ms
    const el: Locator = p.locator("//div[contains(@id,'tab-category')]");
    console.log(await el.count());

    // console.log(await el.first().textContent());
    // await el.first().click();
    const count: number = await el.count();
    for (let i = 0; i < count; i++) {
        console.log(await el.nth(i).textContent());
        var text: string | null = await el.nth(i).textContent();

        if (text?.includes("Kid's Fashion")) {
            await el.nth(i).click();
            break;
        }
    }
    await b.close();
});