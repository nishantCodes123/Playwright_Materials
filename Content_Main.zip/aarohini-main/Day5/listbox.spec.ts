import {test , expect , Browser, Page , Locator} from '@playwright/test';
import { webkit , chromium , firefox } from '@playwright/test';



test ('dateyear' , async()=> {
    const browser :Browser = await chromium.launch({headless : false})
    const page : Page = await browser.newPage();
    await page.goto ("https://register.rediff.com/register/register.php?FormName=user_details")

    await page.locator("//select[contains(@name, 'DOB_Day')]").waitFor({state :'visible'});
    const day : Locator = page.locator("//select[contains(@name, 'DOB_Day')]")
    await day.selectOption({ index :10});

     const month:Locator= page.locator("//select[contains(@name, 'DOB_Month')]");
 //   const day : Locator = page.locator("//select[contains(@name, 'DOB_Day')]")
    await month.selectOption({value:'10'});

     const year:Locator = page.locator("//select[contains(@name, 'DOB_Year')]");
   // const day : Locator = page.locator("//select[contains(@name, 'DOB_Day')]")
    await year.selectOption({label:'2000'});
})