import { Browser, chromium, expect, Locator, Page, test } from '@playwright/test';

test('Amazon check List', async () => {
    const browser: Browser = await chromium.launch({ headless: false });
    const page: Page = await browser.newPage();

    await page.goto('https://www.amazon.com/');
    await page.locator("//input[@id='twotabsearchtextbox']").fill('mobiles');
    await page.keyboard.press('Enter');

//     await page.locator("//span[@class='a-dropdown-prompt']").click();

//    // await  page.locator("//a[@aria-label='Apply the filter Samsung to narrow results']").click();
//    // await page.getByText('Samsung').click()
   await page.waitForSelector("//a[contains(@aria-label,'Samsung')]", { 
        state: 'visible', 
        timeout: 5000 
    });

    await page.locator("//a[contains(@aria-label,'Samsung')]").first().click();

});