import {chromium, expect, test, Page, Browser, Locator, BrowserContext, webkit, firefox} from '@playwright/test';
import { log } from 'node:console';

test('context test', async() => {
    const browser:Browser = await chromium.launch({headless:false});
    const context:BrowserContext = await browser.newContext();
    const context2:BrowserContext = await browser.newContext();
    const user1Page:Page = await context.newPage();

    await user1Page.goto('https://ecommerce-playground.lambdatest.io/index.php?route=account/login');
    await user1Page.getByLabel('E-mail Address').fill('delivery.training21@gmail.com');
    await user1Page.getByLabel('Password').fill('Sample@2025');
    await user1Page.locator("//input[@value='Login']").click();
    const myAccount = await user1Page.getByText('Edit your account information');
    console.log(await myAccount.textContent());
    await expect(myAccount).toBeVisible();


    //user 2

    const user2Page :Page = await context2.newPage();
    
    await user2Page.goto('https://ecommerce-playground.lambdatest.io/index.php?route=account/login');
    
    await expect(await user2Page.getByText('Edit your account information')).toBeVisible();
    

    
});