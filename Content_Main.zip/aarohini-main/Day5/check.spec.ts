import {test , expect , Browser, Page , Locator} from '@playwright/test';
import { webkit , chromium , firefox } from '@playwright/test';



test ('takescreenshot' , async()=> {
    const browser :Browser = await chromium.launch({headless : false})
    const page : Page = await browser.newPage();
    await page.goto ("http://demo.guru99.com/test/radio.html")
    const checkbox1 = await page.locator('#vfb-6-0');
     await expect(checkbox1).not.toBeChecked()
     await checkbox1.check();
     await expect(checkbox1).toBeChecked();

     await browser.close();

})