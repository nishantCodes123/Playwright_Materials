import {test , expect , Browser, Page , Locator, BrowserContext} from '@playwright/test';
import { webkit , chromium , firefox } from '@playwright/test';
import * as path from 'path'


test ('context test' , async()=> {
    const browser :Browser = await chromium.launch({headless : false});
    const context : BrowserContext = await browser.newContext({
    httpCredentials:
        {
            username: 'admin',
            password: 'admin',
        }
    })
    const page : Page = await context.newPage();
    await page.goto("https://the-internet.herokuapp.com/basic_auth");
        console.log(await page.textContent('body'));
        await browser.close();
})