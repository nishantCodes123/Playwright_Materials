import {test , expect , Browser, Page , Locator} from '@playwright/test';
import { webkit , chromium , firefox } from '@playwright/test';


test ('takescreenshot' , async({ page }, testInfo)=> {
    const browser :Browser = await chromium.launch({headless : false})
  //  const page :Page = await browser.newPage();
    await page.goto("https://www.rediff.com/");

    // await page.screenshot({path: './ScreenShot/img2.png', fullPage : false})
    // await testInfo.attach('saved successfully' ,{
    //     path : './ScreenShot/img2.png',
    //     contentType : 'img2,png' // using coma we get the link not the image
 await expect(page).toHaveTitle('Wrong Title');

    })
