import { test, chromium, Browser, Page, BrowserContext } from '@playwright/test';
import * as path from 'path';

test('Goibibo flight booking', async () => {

  const browser: Browser = await chromium.launch({ headless: false });

  const context: BrowserContext = await browser.newContext({
    recordVideo: { dir: path.join('videos') },
  });

  const page: Page = await context.newPage(); 

  await page.goto('https://www.goibibo.com/flights/');

  await page.locator("//span[@class='logSprite icClose']").click();

  await page.locator("//label[@for ='fromCity']").click();
  await page.waitForTimeout(3000);

  await page.locator("//input[@aria-autocomplete='list']").fill('India');
  await page.getByText('Bengaluru, India').click();

  await page.locator("//label[@for='toCity']").click();
  await page.locator("//input[@aria-autocomplete='list']").fill('USA');
  await page.getByText('Usak, Turkey').click();

  while (true) {
    const month = await page.locator("(//div[@class='DayPicker-Caption'])[1]").innerText();

    if (month.includes('May 2026')) {
      console.log("Month found:", month);
      break;
    }

    await page.locator("//span[@aria-label='Next Month']").click();
  }

  await page.locator("(//div[@class='DayPicker-Month'])[1]//p[text()='15']").click();

  await context.close();  
  await browser.close();
});