import { log } from 'node:console';
import { Browser, chromium, expect, Locator, Page, test } from '@playwright/test';

test('Gmail', async () => {
    const browser: Browser = await chromium.launch({ headless: false });
    const page: Page = await browser.newPage();

    await page.goto('https://www.abhibus.com/');
    await page.getByPlaceholder('Leaving From').fill('Che');
    await page.waitForTimeout(5000);
    const element: Locator = await page.locator("//div[@class = 'text-neutral-800 col']");
    // await element.first().waitFor();  
    const count: number = await element.count();
   // console.log(count);
  console.log(await element.allTextContents())
    for(let i =0; i< count; i++){
        let check: string | null = await element.nth(i).innerText();

        if(check?.includes("Guindy")) {
            await page.getByText(check).click();
            console.log(check); 
            break;
        }
    }
})

// import { chromium,Browser,test,BrowserContext,Page,Locator } from "@playwright/test";

// test('abhibus', async()=>{
//     const browser:Browser= await chromium.launch({headless:false});
//     const context:BrowserContext=await browser.newContext();
//     const page:Page=await context.newPage();

//     await page.goto('https://www.abhibus.com/');

//     const from:Locator= page.getByPlaceholder('Leaving From');
//     await from.fill('kol');

//     const autoSuggest:Locator=page.getByText('kollam');
//     await autoSuggest.click();

//     await page.waitForTimeout(5000);3.
    

// })