import { test, Browser, Page, chromium, expect, Locator } from '@playwright/test';


test('Amazon dynamic autosuggest on mobile', async () => {

  const browser: Browser = await chromium.launch({ headless: false });
  const page: Page = await browser.newPage();

  await page.goto('https://www.amazon.com/');

  //await page.locator("//input[@id='twotabsearchtextbox']").click();
  await page.locator("//input[@id='twotabsearchtextbox']").fill("mobile");
  await page.locator("//input[@id='twotabsearchtextbox']").press("Enter");
  await page.waitForTimeout(3000);
  // get all products using the same XPath you provided
  const products: Locator = page.locator("//a[@class='a-link-normal s-line-clamp-2 puis-line-clamp-3-for-col-4-and-8 s-link-style a-text-normal']");

  const count: number = await products.count();
  console.log(count);
  
  for (let i = 0; i < count; i++) {

    const text = await products.nth(i).innerText();

    console.log(`Found product: ${text}`);

    if (text.includes("Samsung Galaxy S26+")) {
      console.log(`Found and clicking: ${text}`);
      await products.nth(i).click();
      break;
    }
  }
  await page.waitForTimeout(5000);

  await browser.close();
});

/*
import { Browser, chromium, expect, Locator, Page, test } from '@playwright/test';

test('Amazon', async () => {
    const browser: Browser = await chromium.launch({ headless: false });
    const page: Page = await browser.newPage();

    await page.goto('https://www.amazon.com/');
    await page.locator("//input[@id = 'twotabsearchtextbox']").fill('laptops');
await page.keyboard.press('Enter');
  await page.waitForTimeout(3000);
    const ele = await page.locator("//a[@class = 'a-link-normal s-line-clamp-2 puis-line-clamp-3-for-col-4-and-8 s-link-style a-text-normal']")
    const count :number = await ele.count();
        console.log(count);

        for(let i = 0; i< await ele.count(); i++){
            console.log(await ele.nth(i).textContent());

        }

   // await page.goto("//div[@class = 'puisg-col-inner']")
    
})

*/