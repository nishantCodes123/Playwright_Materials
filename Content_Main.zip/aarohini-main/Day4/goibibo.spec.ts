import { test, chromium, Browser, Page } from '@playwright/test';

test('Goibibo flight booking', async () => {

  const browser: Browser = await chromium.launch({ headless: false });
  const page: Page = await browser.newPage();

  const travelDate = '15';   

  await page.goto('https://www.goibibo.com/flights/?utm_source=google&utm_medium=cpc&utm_campaign=DF-Brand-EM&utm_adgroup=Goibibo-Flight&utm_term=!SEM!DF!G!Brand!RSA&cmp=SEM|D|DF|G|Google-CPC-Brand|DF-Brand-EM|Goibibo-Flight|RSA%3E&gad_source=1&gad_campaignid=108599293&gbraid=0AAAAADrlxCc7qWKYEGFAukQAT4od5yLVO&gclid=Cj0KCQjwgr_NBhDFARIsAHiUWr7eayRpmibuoV6c2cIIC_5Vg0trWNGg5gCJ2JxvRQP4kTlisno-YXIaAs2bEALw_wcB');
 // await page.locator("//html/body/div").click();
  await page.locator("//span[@class='logSprite icClose']").click();

  await page.locator("//label[@for ='fromCity']").click();
  await page.waitForTimeout(3000);
  await page.locator("//input[@aria-autocomplete= 'list']").fill('India');
  await page.getByText('Bengaluru, India').click();

  await page.locator("//label[@for='toCity']").click();
  await page.locator("//input[@aria-autocomplete= 'list']").fill('USA'); 
  await page.getByText('Usak, Turkey').click(); 

  while (true) {

    const month = await page.locator("(//div[@class='DayPicker-Caption'])[1]").innerText();

    if (month.includes('May 2026')) {
      console.log("Month found:", month);
      break;
    }

    await page.locator("//span[@aria-label='Next Month']").click();
  }

  await page.locator("(//div[@class='DayPicker-Month'])[1]//p[text()='15']").click();

});