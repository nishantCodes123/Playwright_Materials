import { test, Browser, Page, chromium, expect } from '@playwright/test';

test('OrangeHRM Login and Leave Page', async () => {

const browser: Browser = await chromium.launch({ headless:false });
const page: Page = await browser.newPage();

await page.goto("https://opensource-demo.orangehrmlive.com/", {timeout:60000});

await page.getByPlaceholder('Username').waitFor({state:'visible'});
await page.getByPlaceholder('Username').fill('Admin');
await page.getByPlaceholder('Password').fill('admin123');


await page.getByRole('button', {name: ' Login ' }).waitFor({state:'visible'});
await page.getByRole('button', {name: /login/i }).click();

});


