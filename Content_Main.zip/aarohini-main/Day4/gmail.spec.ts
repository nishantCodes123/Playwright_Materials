
import { Browser, chromium, Locator, Page, test } from '@playwright/test';

test('gmail TEST', async ({ page }) => {



    await page.goto('https://www.google.com/');

    await page.getByRole('link', { name: 'Gmail ' })

    await page.getByRole('link', { name: /Gmail/i }).click();
    await page.waitForTimeout(6000);

});