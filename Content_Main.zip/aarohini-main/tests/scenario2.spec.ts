import { test, expect, chromium, Browser, Page } from '@playwright/test';
import path from "path";
import { readSheet4 } from '../utils/excelReader.ts';

const filePath = path.join(__dirname,"../testdata/testdata.xlsx"); 
const details= readSheet4(filePath);

for (const row of details) {
test('Flipkart Price Filter Validation', async () => {

    const data = readSheet4('testdata/testdata.xlsx');


        const browser: Browser = await chromium.launch({ headless: false });
        const page: Page = await browser.newPage();

        await page.goto("https://www.flipkart.com/");

        // close login popup
        await page.locator("//span[@role='button' and text()='✕']").click();

        // search product and click Enter
        await page.getByRole('textbox', { name: 'Search for Products, Brands' }).fill(row.Product);
        await page.keyboard.press("Enter");

        await page.waitForTimeout(3000);

        // assert the URL
        await expect(page).toHaveURL(new RegExp(row.expectedURL));
        await page.waitForSelector("//select[@class='hbnjE2']");

        // apply min price
        await page.locator("//select[@class='hbnjE2']").first().selectOption(row.priceMin);
        await page.waitForLoadState('networkidle');

        // apply max price
        await page.locator("//select[@class='hbnjE2']").last().selectOption(row.priceMax);
        await page.waitForLoadState('networkidle');
        
        // open first product
        const [newPage] = await Promise.all([
            page.context().waitForEvent('page'),
            page.locator("//div[@class='RGLWAk']").first().click()
        ]);

        await newPage.waitForLoadState();

        // get price
        const priceText = await newPage.locator("//div[@class='v1zwn21k v1zwn20 _1psv1zeb9 _1psv1ze0']").textContent();

        // print the Title of the product 
        console.log(await newPage.locator("//div[@class='v1zwn21k v1zwn26 _1psv1zeb9 _1psv1ze0']").first().textContent());
        

        const price = Number(priceText?.replace(/[₹,]/g, ''));

        console.log("Product Price:", price);
        console.log(priceText);
        

        // expect(price).toBeGreaterThanOrEqual(Number(row.minPrice));
        // expect(price).toBeLessThanOrEqual(Number(row.maxPrice));

        const min = Number(row.priceMin);
        const max = Number(row.priceMax);

        if (price >= min && price <= max) {
            console.log("Price is within range");
          } else {
            console.log("Price is NOT within range");
            throw new Error(`Price ${price} is outside range ${min} - ${max}`);
         }

        await newPage.close();
        await page.waitForTimeout(4000); 
        await browser.close();
    

});
}