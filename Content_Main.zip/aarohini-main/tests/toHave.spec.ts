import { test, expect } from '@playwright/test';

test('Check URL and Title', async ({ page }) => {

  await page.goto('https://m.rediff.com/');

  await expect(page).toHaveURL(/rediff/);

  await expect(page).toHaveTitle(/Stock Quotes/);

});