
import {test, Browser, BrowserContext, Page, Locator, expect} from '@playwright/test';
import {webkit, chromium, firefox} from 'playwright';

test('Locator test', async() => {
    const browser:Browser = await chromium.launch({headless:false});
    const page:Page = await browser.newPage();
    await page.goto('https://www.amazon.in/');

    // await page.locator("//textarea[@id='APjFqb']").fill('AOT');
    // await page.locator("//*[@id='APjFqb']").press('Enter');
    //two times locating the same element is consuming more time and 
    //also if we have to perform multiple action on the same element 
    //here we are storing the locator in a variable and then performing action on it

    const textBox:Locator = await page.locator("//input[@id='twotabsearchtextbox']");
    await textBox.fill('AOT');
    await textBox.press('Enter');

    await expect(page).toHaveTitle('Amazon.in : AOT');

    //using css selector
    // await page.locator('#APjFqb').fill('AOT');
    await page.locator("//a[text()='Amazon Pay']").click(); //using Xpath
                        //span[contains(text(),'Amazon Pay')]

    // await page.locator('#APjFqb').press('Enter');

});