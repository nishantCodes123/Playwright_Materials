import {test,expect,Browser,Page,chromium} from "@playwright/test";
import path from "path";
import { readSheet2 } from "../utils/excelReader";

const filePath = path.join(__dirname,"../testdata/testdata.xlsx"); 
const details= readSheet2(filePath);

for(const data of details){
test('Verify product rating',async()=>{
  const browser:Browser=await chromium.launch({headless:false});
  const page:Page=await browser.newPage();

  await page.goto("https://www.flipkart.com/");
    await page.getByRole('button',{name:'✕'}).click();
    await page.getByPlaceholder('Search for Products, Brands and More').first().fill(data.Product);
    await page.keyboard.press('Enter');
    const element=page.locator("//a[@class='pIpigb']");
    await element.first().waitFor({state:'visible'});

    const count=await element.count();
    
    for(let i=0;i<count;i++){
      const txt=await element.nth(i).innerText();
      
        if(txt?.includes(data.Item)){
          const[popup]=await Promise.all([
            page.waitForEvent('popup'),
             element.nth(i).click(),
          ])
          await popup.waitForLoadState();
          const rating = popup.getByRole('link',{name:'4.8'}).first();
          await expect(rating).toBeVisible();

         const ratingText = await rating.textContent();
         expect(ratingText?.trim()).toContain(data.review.toString());

        }
    }
});
}

