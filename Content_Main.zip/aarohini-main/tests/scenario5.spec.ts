import { test, expect } from "@playwright/test";
import path from 'path';
import { readSheet5 } from "../utils/excelReader";

const filePath= path.join(__dirname, "../testData/testdata.xlsx");
const records= readSheet5(filePath);

for(const data of records){
  test("Verify Product Specification", async ({ page }) => {

  await page.goto("https://www.flipkart.com/");

  await page.getByRole('button',{name:'✕'}).click();
  const searchBox = page.getByPlaceholder("Search for Products, Brands and More");
  await searchBox.first().fill(data.Product);
  await page.keyboard.press("Enter");


const listItems= page.locator("//a[@class='k7wcnx']");
await listItems.first().waitFor({state:'visible'})
const countItems= await listItems.count();
 console.log(countItems);
for(let i=0;i<countItems;i++){
  const txt:string|null= await listItems.nth(i).textContent();
  if(txt?.includes(data.Item)){
    const [newTab]= await Promise.all([
      page.waitForEvent('popup'),
      listItems.nth(i).click(),
    ]);
    console.log("New Tab Title:", await newTab.title());


const specsSection = newTab.locator("text=Specifications");
await specsSection.scrollIntoViewIfNeeded();
const readMore = newTab.locator("text=See More");
if (await readMore.isVisible()) {
  await readMore.click();
}
await newTab.waitForTimeout(2000);

await expect(newTab.locator("text=MediaTek").first()).toBeVisible();
  }
}

});
}