import {test,expect,Page,chromium,Browser} from '@playwright/test';
import path from 'path';
import { readSheet1 } from '../utils/excelReader';

const filepath = path.join(__dirname, "../testdata/testdata.xlsx");
const records= readSheet1(filepath);
for(const data of records){
test('verify product title',async()=>{
    const browser:Browser=await chromium.launch({headless:false});
    const page:Page=await browser.newPage();
    await page.goto("https://www.flipkart.com/");
    await page.getByRole('button',{name:'✕'}).click();
    await page.getByPlaceholder('Search for Products, Brands and More').first().fill(data.Product);
    await page.keyboard.press('Enter');
    const element= page.locator("//a[@class='atJtCj Qum9aC']");
    await element.first().waitFor({state:'visible'})
    const counts= await element.count();
    console.log(counts);
    for(let i=0;i<counts;i++){
      const txt=await element.nth(i).innerHTML();
      console.log(txt);
      if(txt.includes(data.Item)){
        const [popup]=await Promise.all([
         page.waitForEvent('popup'),
         element.nth(i).click(),
        ])
        await popup.waitForLoadState();
        await expect(popup).toHaveTitle(/Fire-Boltt/)
        break;
      }
    }
    await page.close();
 });
};