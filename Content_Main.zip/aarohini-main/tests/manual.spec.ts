import {test, Browser, BrowserContext, Page} from '@playwright/test';
import {webkit, chromium, firefox} from 'playwright';

//manually creating my environment
test('Sample Test', async() => {
    
    const browser:Browser = await chromium.launch({headless:false});
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();
    await page.goto('https://www.google.com/');

    //manually if we're creating then it shouldn't 
    // close without testRunner (built-in)
    await browser.close();
});