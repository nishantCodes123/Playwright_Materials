import {test, Browser, BrowserContext, Page, expect} from '@playwright/test';
import {webkit, chromium, firefox} from 'playwright';

test('Sample Test', async() => {
    
    const browser:Browser = await chromium.launch({headless:false});

    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();
    await page.goto('https://pay.rediff.com/webapp/?utm_source=rediff_home_icon&utm_medium=pc&utm_campaign=rediffpay&utm_content=rediffpay_rediff_home_icon_pc');
    await expect(page).toHaveTitle('Rediff App');
    await expect(page).toHaveURL('https://pay.rediff.com/webapp/?utm_source=rediff_home_icon&utm_medium=pc&utm_campaign=rediffpay&utm_content=rediffpay_rediff_home_icon_pc');
    await expect(page.url()).toContain('rediff');

    //manually if we're creating then it shouldn't 
    // close without testRunner (built-in)
    await browser.close();
});