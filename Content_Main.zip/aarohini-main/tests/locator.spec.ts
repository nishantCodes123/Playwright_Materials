
import {test, Browser, BrowserContext, Page} from '@playwright/test';
import {webkit, chromium, firefox} from 'playwright';

test('Locator test', async() => {
    const browser:Browser = await chromium.launch({headless:false});
    const page:Page = await browser.newPage();
    await page.goto('https://www.google.com');

    await page.locator("//textarea[@id='APjFqb']").fill('AOT');
    await page.locator("//*[@id='APjFqb']").press('Enter');

    

    //using css selector
    // await page.locator('#APjFqb').fill('AOT');

    // await page.locator('#APjFqb').press('Enter');

});