import { test, expect, Browser, BrowserContext, chromium, Page } from '@playwright/test';
import path from 'path';
import { readSheet3 } from '../utils/excelReader';

const filePath = path.join(__dirname, "../testdata/testdata.xlsx");
const records = readSheet3(filePath);

for (const data of records) {
test(`Verify Add To Cart for ${data.searchItem}`, async ({ }) => {

    const browser:Browser = await chromium.launch({headless:false});
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();
    

    await page.goto("https://www.flipkart.com/");

    //close the login popup 
    await page.getByRole('button', { name: '✕' }).click();
//search product 'backpack/laptop bag'
    await page.getByPlaceholder('Search for Products, Brands and More').first().fill(data.searchItem);

    await page.keyboard.press('Enter');

    // openign first product
   const product = page.locator("a[href*='/p/']").first();

const [newPage] = await Promise.all([
  page.context().waitForEvent('page'),
  product.click()
]);

await newPage.waitForLoadState();
const addToCartBtn = newPage.getByText(data.expected);
await addToCartBtn.click();
await browser.close();
});

}