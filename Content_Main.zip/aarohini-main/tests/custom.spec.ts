import { test as base } from '@playwright/test';
import { log } from 'node:console';
const test = base.extend({
    myPage: async ({ page }, use) => {
        await page.goto('https://www.google.com/');
        await use(page);
    }
});

test('custom fixture example', async ({ myPage }) => {
    console.log(await myPage.title());
    
});


