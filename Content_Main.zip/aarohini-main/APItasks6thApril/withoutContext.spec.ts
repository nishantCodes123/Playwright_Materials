import { test, expect, APIResponse } from '@playwright/test';
//without context, without fixture, without config

test('GET API', async () => {
  const response = await fetch('https://restful-booker.herokuapp.com/booking');
  const data = await response.json();

  console.log(data);
});

// test('GET API Test1', async() => {
//   let response= await fetch('https://restful-booker.herokuapp.com/booking', {
//     method: 'GET',
//     headers: {  'Content-Type': 'application/json' }
//   });
//   const body = await response.json();
//   console.log(body);
//   expect(response.status).toBe(200);   
                                                              
// });




