import {test, expect, APIResponse} from '@playwright/test'

test('GET API Test', async({request}) => {
    const start: number = Date.now();
    const response:APIResponse = await request.get('https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos');
    const duration:number = Date.now() - start;
    const body = await response.json();
    console.log(body);
    expect(response.status()).toBe(200);
    expect(response.statusText()).toBe('OK');
    expect(body.length).toBeGreaterThan(0);
    expect(Array.isArray(body)).toBe(true);
    expect(body[0]).toHaveProperty('idBook');
    expect(body[0].idBook).toBe(1);
    expect(typeof body[0].idBook).toBe('number');
    expect(response.headers()['content-type']).toBeTruthy();
    expect(response.headers()['content-type']).toContain('application/json');
    expect(duration).toBeLessThan(3000);
    

    
});