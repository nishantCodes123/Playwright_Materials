import { test, expect, APIResponse } from '@playwright/test';


test('GET API Test1', async({request}) => {
  const repsonse:APIResponse = await request.get('/booking');
  const body = await repsonse.json();
  console.log(body);
  expect(repsonse.status()).toBe(200);
  
});

