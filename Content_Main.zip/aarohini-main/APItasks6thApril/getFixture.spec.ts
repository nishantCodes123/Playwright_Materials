import { test, expect, APIResponse } from '@playwright/test';


test('GET API Test1', async({request}) => {
  const repsonse:APIResponse = await request.get('https://restful-booker.herokuapp.com/booking',
    {
        headers: {
            'Content-Type': 'application/json'
        }
});
  console.log(await repsonse.json());
  expect(repsonse.status()).toBe(200);
  
});

