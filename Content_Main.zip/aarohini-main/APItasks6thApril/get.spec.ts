import { test, expect, request, APIRequestContext, APIResponse } from '@playwright/test';

let apiRequest:APIRequestContext;

test.beforeAll('Before All Test', async() => {
  apiRequest = await request.newContext({
    baseURL: 'https://restful-booker.herokuapp.com',
    extraHTTPHeaders: {
      'Content-Type': 'application/json'
    }
  });
});

test('GET API Test1', async() => {
  const repsonse:APIResponse = await apiRequest.get('/booking');
  console.log(await repsonse.json());
  expect(repsonse.status()).toBe(200);
  
});

test('GET API Test2', async() => {
  const repsonse:APIResponse = await apiRequest.get('/booking/2');
  console.log(await repsonse.json());
  expect(repsonse.status()).toBe(200);
  
});



test.afterAll(async() => {
  await apiRequest.dispose();
});
