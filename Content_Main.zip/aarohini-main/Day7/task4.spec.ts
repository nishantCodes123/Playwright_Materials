import { test, expect } from '@playwright/test';

test('Practo', async ({ page }, testInfo) => {

  await page.goto('https://www.practo.com/');
  await page.waitForTimeout(3000);

  await page.locator("//input[@placeholder='Search doctors, clinics, hospitals, etc.']").click();
  await page.locator("//div[text()='Dentist']").first().click();

  const res = page.locator("//div[@class='reach-v2-card u-border-general--top']").first();
  await expect(res).toContainText('Clinic');

  // take screenshot
  await page.screenshot({ path: './ScreenShot/img3.png', fullPage: false });

  // attach screenshot to report
  await testInfo.attach('Practo Screenshot', {
    path: './ScreenShot/img3.png',
    contentType: 'image/png'
  });
    
});