/* 
MagicBricks: Go to https://www.magicbricks.com
Go to login and close the new tab that opens 
*/

import {test, expect, chromium, Browser, BrowserContext, Page} from '@playwright/test';

test('Magic Bricks', async() => {
    const browser:Browser = await chromium.launch({headless:false});
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();

    await page.goto('https://www.magicbricks.com');

    await page.waitForTimeout(3000);

    await page.getByText('Login', {exact:true}).click();

     
    const [popup] = await Promise.all([
        page.waitForEvent('popup'),
        page.getByText('Login/Sign Up').click()
    ]);

    await popup.waitForLoadState()
    await expect(popup).toHaveTitle('User Login');

    await popup.close();

    
});



        

