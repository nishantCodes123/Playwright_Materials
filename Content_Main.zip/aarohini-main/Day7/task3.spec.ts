/* Task 3: 
Go to https://www.naukri.com/
get search results for test

*/

import {test, expect, Browser, BrowserContext, Page, chromium} from '@playwright/test';

test('naukri task', async({}, testInfo) => {
    const browser:Browser = await chromium.launch({headless:false});
    const context:BrowserContext = await browser.newContext();
    const page:Page = await context.newPage();

    await page.goto('https://www.naukri.com/');

    await page.waitForTimeout(1000);

    await page.locator('//html/body/div[1]/div[7]/div/div/div[1]/div/div/div[1]/div[1]/div/input').fill('test');
    await page.waitForTimeout(1000);

    await page.getByText('Test Engineer',{ exact: true }).click();
    await page.waitForTimeout(1000);
    

    await page.locator('//html/body/div[1]/div[7]/div/div/div[3]/div/input').click();
    await page.waitForTimeout(2000)
    await page.getByText("less than 1 year").click();

    await page.locator('//html/body/div[1]/div[7]/div/div/div[5]/div/div/div/div[1]/div/input').fill('Kol');
    await page.waitForTimeout(2000)
    await page.getByText("Kolkata").click();
    await page.locator('//html/body/div[1]/div[7]/div/div/div[6]').click()
    
    await page.locator('//html/body/div/div/main/div[1]/div[1]/div/div').getByText('Work from office').click();


    await page.waitForTimeout(4000);

    const result1= await page.locator('//html/body/div/div/main/div[1]/div[2]/div[2]/div/div[1]/div');

    await expect(result1).toContainText(/test/);

        await page.screenshot({path: './Screenshot/Image1.png', fullPage : false})
        await testInfo.attach('saved successfully' ,{
        path : './Screenshot/Image1.png',
        contentType : 'Image1/png' // using coma we get the link not the image
        

    })




})