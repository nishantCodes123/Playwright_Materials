/*
Playwright commands to:

A. Installing Playwright:
---------------------------
npm init playwright@latest


B. Executing test case: 
------------------------
npx playwright test


C. Executing a particular test case:
--------------------------------------
npx playwright test example.spec.ts


D. Executing Test cases in Headed mode on a particular browser:
----------------------------------------------------------------
npx playwright test example.spec.ts --headed --project=chromium
npx playwright test example.spec.ts --headed --project=firefox
npx playwright test example.spec.ts --headed --project=webkit


E. Executing a particular test case (Allocating the worker manually):
-----------------------------------------------------------------------
npx playwright test example.spec.ts --workers=1

*/