import { Page,expect } from '@playwright/test';

export default class Assert {
    constructor(public page: Page) {}

   async verifyTitle(text: string) {
    const pattern = text.split(" ").join(".*");
    await expect(this.page).toHaveTitle(new RegExp(pattern, 'i'));
}
}

export async function verifyVisible(locator: any) {
    await expect(locator).toBeVisible();

    
}                                                                            