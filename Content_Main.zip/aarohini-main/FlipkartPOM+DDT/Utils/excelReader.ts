import * as EXCEL from 'xlsx';
import fs from 'fs';
type Sheet1Record={
    Product:string;
    Item:string;

};
type Sheet2Record = {
  Product: string;
  Item: string;
  review: string;
};
type Sheet5Record={
    Product:string;
    Item:string;

};
type Sheet4Record={
  Product:string;
  minPrice:string;
  maxPrice:string;
  expectedURL:string;
}
type Sheet3Record={
    searchItem:string;
    expected:string;

};



// export function readExcelFILE(filepath:string,sheetName:string){
//     const file = fs.readFileSync(filepath);
//     const workbook=EXCEL.read(file,{type:"buffer"});
//     const sheet= workbook.Sheets[sheetName];
//     const rawData:any[]=EXCEL.utils.sheet_to_json(sheet,{header:1})
//     const records:Sheet1Record[] | Sheet2Record[]= rawData.slice(1).map((column:any)=>({
//         Product:column[0],
//         Item:column[1],
//     }))
//     return records;
// }
export function readSheet1(filepath: string) {
  const file = fs.readFileSync(filepath);
  const workbook = EXCEL.read(file, { type: "buffer" });
  const sheet = workbook.Sheets["Sheet1"];

  const rawData: any[] = EXCEL.utils.sheet_to_json(sheet, { header: 1 });

  return rawData.slice(1).map((row) => ({
    Product: row[0],
    Item: row[1],
  }));
}

export function readSheet2(filepath: string) {
  const file = fs.readFileSync(filepath);
  const workbook = EXCEL.read(file, { type: "buffer" });
  const sheet = workbook.Sheets["Sheet2"];

  const rawData: any[] = EXCEL.utils.sheet_to_json(sheet, { header: 1 });

  return rawData.slice(1).map((row) => ({
    Product: row[0],
    Item: row[1],
    review: row[2],
  }));
}

export function readSheet4(filepath: string) {
  const file = fs.readFileSync(filepath);
  const workbook = EXCEL.read(file, { type: "buffer" });
  const sheet = workbook.Sheets["Sheet4"];

  const rawData: any[] = EXCEL.utils.sheet_to_json(sheet, { header: 1 });

  return rawData.slice(1).map((row) => ({
     Product: row[0],
    priceMin: String(row[1]),
    priceMax: String(row[2]),
    expectedURL: row[3],

  }));
}

export function readSheet5(filepath: string) {
  const file = fs.readFileSync(filepath);
  const workbook = EXCEL.read(file, { type: "buffer" });
  const sheet = workbook.Sheets["Sheet3"];

  const rawData: any[] = EXCEL.utils.sheet_to_json(sheet, { header: 1 });

  return rawData.slice(1).map((row) => ({
    Product: row[0],
    Item: row[1],
  }));
}

export function readSheet3(filepath: string) {
  const file = fs.readFileSync(filepath);
  const workbook = EXCEL.read(file, { type: "buffer" });
  const sheet = workbook.Sheets["Sheet5"];

  const rawData: any[] = EXCEL.utils.sheet_to_json(sheet, { header: 1 });

  return rawData.slice(1).map((row) => ({
    searchItem: row[0],
    expected: row[1],
  }));
}