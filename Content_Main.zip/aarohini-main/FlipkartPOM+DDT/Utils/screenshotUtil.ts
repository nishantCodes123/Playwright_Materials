import { Page, test } from '@playwright/test';

export async function takeScreenshot(page: Page, name: string, testInfo: any) {

    const screenshot = await page.screenshot({
        path: `Screenshots/${name}.png`,
        fullPage: true
    });

    await testInfo.attach(name, {
        body: screenshot,
        contentType: 'image/png'
    });
}