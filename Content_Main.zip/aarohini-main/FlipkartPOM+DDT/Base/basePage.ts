import { Page } from '@playwright/test';

export default class BasePage {
    page: Page;

    constructor(page: Page) {
        this.page = page;
    }

    async navigate(url: string) {
        await this.page.goto(url);
    }

    async waitForPageLoad() {
        await this.page.waitForLoadState('networkidle');
    }

    async close(){
        await this.page.close();
    }
}