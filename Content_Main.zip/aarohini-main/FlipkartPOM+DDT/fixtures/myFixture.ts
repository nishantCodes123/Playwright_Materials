import {test as SampleTest} from '@playwright/test';
export const mytest=SampleTest.
extend<{data:{url:string}}>({
    data:async({},use)=>{
        await use({url: "https://www.flipkart.com/"});
    } ,
})