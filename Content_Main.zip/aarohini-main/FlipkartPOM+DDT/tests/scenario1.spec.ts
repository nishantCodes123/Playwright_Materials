import { mytest } from '../fixtures/myFixture';
import path from 'path';
import { readSheet1 } from '../Utils/excelReader';
import HomePage from '../Pages/homePage';
import SearchPage from '../Pages/searchPage';
import ProductPage from '../Pages/productPage';
import BasePage from '../Base/basePage';
import Assert from '../Utils/assertionUtil';
import { takeScreenshot } from '../Utils/screenshotUtil';

const records = readSheet1(path.join(__dirname, "../TestData/testdata.xlsx"));

for (const datas of records) {

mytest('verify product title', async ({ page, data }, testInfo) => {

    const base = new BasePage(page);
    const home = new HomePage(page);
    const search = new SearchPage(page);

    await home.navigate(data.url);
    await home.closePopup();

    await search.search(datas.Product);

    const newPage = await search.openProductScenario1(datas.Item);

    const product = new ProductPage(newPage);

    const assert:Assert = new Assert(page);
    
    await product.verifyTitle(datas.Item);

    await takeScreenshot(page, 'image1', testInfo);

    await base.close();

});
}