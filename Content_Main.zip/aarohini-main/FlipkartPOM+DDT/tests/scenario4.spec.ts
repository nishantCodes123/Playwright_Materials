import { mytest } from '../fixtures/myFixture';
import path from 'path';
import { readSheet3 } from '../Utils/excelReader';
import HomePage from '../Pages/homePage';
import SearchPage from '../Pages/searchPage';
import ProductPage from '../Pages/productPage';
import Assert, { verifyVisible } from '../Utils/assertionUtil';
import { takeScreenshot } from '../Utils/screenshotUtil';
import BasePage from '../Base/basePage';

const records = readSheet3(path.join(__dirname, "../TestData/testdata.xlsx"));

for (const datas of records) {

mytest('Verify Add To Cart', async ({ page, data }) => {
    
    const base = new BasePage(page);

    const home = new HomePage(page);
    const search = new SearchPage(page);

    await home.navigate(data.url);
    await home.closePopup();

    await search.search(datas.searchItem);

    const newPage = await search.openFirstProduct();

    const product = new ProductPage(newPage);
    const assert:Assert = new Assert(page);
    await verifyVisible(datas.expected);
    await takeScreenshot(page, 'image4');
    await base.close();


});
}