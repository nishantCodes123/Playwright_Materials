import { mytest } from '../fixtures/myFixture';
import path from 'path';
import { readSheet5 } from '../Utils/excelReader';
import HomePage from '../Pages/homePage';
import SearchPage from '../Pages/searchPage';
import ProductPage from '../Pages/productPage';
import { takeScreenshot } from '../Utils/screenshotUtil';
import BasePage from '../Base/basePage';
import Assert from '../Utils/assertionUtil';

const records = readSheet5(path.join(__dirname, "../TestData/testdata.xlsx"));

for (const datas of records) {

mytest('Verify Product Specification', async ({ page, data }) => {

    const base = new BasePage(page);
    const home = new HomePage(page);
    const search = new SearchPage(page);

    await home.navigate(data.url);
    await home.closePopup();

    await search.search(datas.Product);

    const newPage = await search.openProductScenario5(datas.Item);

    const product = new ProductPage(newPage);
    const assert:Assert = new Assert(page);

    await product.verifySpecifications("MediaTek");
    await takeScreenshot(page, 'image5');
    await base.close();


});
}