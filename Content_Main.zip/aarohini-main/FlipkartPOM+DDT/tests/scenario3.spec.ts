import { mytest } from '../fixtures/myFixture';
import path from 'path';
import { readSheet2 } from '../Utils/excelReader';
import HomePage from '../Pages/homePage';
import SearchPage from '../Pages/searchPage';
import ProductPage from '../Pages/productPage';
import BasePage from '../Base/basePage';
import Assert from '../Utils/assertionUtil';
import { takeScreenshot } from '../Utils/screenshotUtil';

const records = readSheet2(path.join(__dirname, "../TestData/testdata.xlsx"));

for (const datas of records) {

mytest('Verify product rating', async ({ page, data }) => {

    const base = new BasePage(page);
    const home = new HomePage(page);
    const search = new SearchPage(page);

    await home.navigate(data.url);
    await home.closePopup();

    await search.search(datas.Product);

    const newPage = await search.openProductScenario3(datas.Item);

    const product = new ProductPage(newPage);

    const assert:Assert = new Assert(page);

    await product.verifyRating(datas.review.toString());

    await takeScreenshot(page, 'image3');
    await base.close();


});
}