import { Page, Locator } from '@playwright/test';

export default class SearchPageLocators {
    constructor(public page: Page) {}

    async searchBox(): Promise<Locator> {
        return this.page.getByPlaceholder('Search for Products, Brands and More').first();
    }

    async listScenario1(): Promise<Locator> {
        return this.page.locator("//a[@class='atJtCj Qum9aC']");
    }

    async listScenario3(): Promise<Locator> {
        return this.page.locator("//a[@class='pIpigb']");
    }

    async listScenario5(): Promise<Locator> {
        return this.page.locator("//a[@class='k7wcnx']");
    }

    async firstProductScenario2(): Promise<Locator> {
        return this.page.locator("//div[@class='RGLWAk']").first();
    }



    async firstProduct(): Promise<Locator> {
        return this.page.locator("a[href*='/p/']").first();
    }
}