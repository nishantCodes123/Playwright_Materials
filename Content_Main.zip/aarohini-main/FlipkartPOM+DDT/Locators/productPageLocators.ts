import { Page, Locator } from '@playwright/test';

export default class ProductPageLocators {
    constructor(public page: Page) {}

    async addToCart(expected: string): Promise<Locator> {
        return this.page.getByText(expected);
    }

    async rating(): Promise<Locator> {
        return this.page.getByRole('link', { name: '4.8' }).first();
    }
















    

    async specs(): Promise<Locator> {
        return this.page.locator("text=Specifications");
    }

    async readMore(): Promise<Locator> {
        return this.page.locator("text=See More");
    }
}