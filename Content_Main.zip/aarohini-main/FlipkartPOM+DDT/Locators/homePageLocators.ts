import { Page, Locator } from '@playwright/test';

export default class HomePageLocators {
    constructor(public page: Page) {}

    async closePopup(): Promise<Locator> {
        return this.page.getByRole('button', { name: '✕' });
    }
}