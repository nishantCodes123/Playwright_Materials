import { Page } from '@playwright/test';
import SearchPageLocators from '../Locators/searchPageLocators';

export default class SearchPage {
    locators: SearchPageLocators;

    constructor(public page: Page) {
        this.locators = new SearchPageLocators(page);
    }

    async search(item: string) {
        const box = await this.locators.searchBox();
        await box.fill(item);
        await this.page.keyboard.press('Enter');
    }

    // Scenario 1
    async openProductScenario1(item: string): Promise<Page> {
        const list = await this.locators.listScenario1();
        await list.first().waitFor({ state: 'visible' });

        const count = await list.count();

        for (let i = 0; i < count; i++) {
            const txt = await list.nth(i).innerHTML();

            if (txt.includes(item)) {
                const [popup] = await Promise.all([
                    this.page.waitForEvent('popup'),
                    list.nth(i).click(),
                ]);
                await popup.waitForLoadState();
                return popup;
            }
        }
        throw new Error(`Product "${item}" not found`);
    }

    // Scenario 3
    async openProductScenario3(item: string) {
        const list = await this.locators.listScenario3();
        await list.first().waitFor({ state: 'visible' });

        const count = await list.count();

        for (let i = 0; i < count; i++) {
            const txt = await list.nth(i).innerText();

            if (txt.includes(item)) {
                const [popup] = await Promise.all([
                    this.page.waitForEvent('popup'),
                    list.nth(i).click(),
                ]);
                await popup.waitForLoadState();
                return popup;
            }
        }
        throw new Error(`Product "${item}" not found`);
    }

    // Scenario 5
    async openProductScenario5(item: string) {
        const list = await this.locators.listScenario5();
        await list.first().waitFor({ state: 'visible' });

        const count = await list.count();

        for (let i = 0; i < count; i++) {
            const txt = await list.nth(i).textContent();

            if (txt?.includes(item)) {
                const [popup] = await Promise.all([
                    this.page.waitForEvent('popup'),
                    list.nth(i).click(),
                ]);
                await popup.waitForLoadState();
                return popup;
            }
        }
        throw new Error(`Product "${item}" not found`);
    }


    // Scenario 4
    async openFirstProduct() {
        const product = await this.locators.firstProduct();

        const [newPage] = await Promise.all([
            this.page.context().waitForEvent('page'),
            product.click()
        ]);

        await newPage.waitForLoadState();
        return newPage;
    }
}