import { Page, expect } from '@playwright/test';
import ProductPageLocators from '../Locators/productPageLocators';

export default class ProductPage {
    locators: ProductPageLocators;

    constructor(public page: Page) {
        this.locators = new ProductPageLocators(page);
    }

    async verifyTitle(text: string) {
        await expect(this.page).toHaveTitle(new RegExp(text, 'i'));
    }

 async verifyAddToCartVisible(expected: string) {
    const btn = await this.locators.addToCart(expected);
    await expect(btn).toBeVisible();
}
    async verifyRating(expected: string) {
        const rating = await this.locators.rating();
        await expect(rating).toBeVisible();

        const txt = await rating.textContent();
        expect(txt?.trim()).toContain(expected);
    }



    async verifySpecifications(text: string) {
        const specs = await this.locators.specs();
        await specs.scrollIntoViewIfNeeded();

        const readMore = await this.locators.readMore();
        if (await readMore.isVisible()) {
            await readMore.click();
        }

        await expect(this.page.locator(`text=${text}`).first()).toBeVisible();
    }
}