import { Page } from '@playwright/test';
import HomePageLocators from '../Locators/homePageLocators';

export default class HomePage {
    locators: HomePageLocators;

    constructor(public page: Page) {
        this.locators = new HomePageLocators(page);
    }

    async navigate(url:string) {
        await this.page.goto(url);
    }

    async closePopup() {
        const btn = await this.locators.closePopup();
        await btn.click();
    }
}